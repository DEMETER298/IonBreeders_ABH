#!bin/bash
#ABH plugin
#
VERSION="1.0"

plugin_url=http://127.0.0.1/rundb/api/v1/results/${RUNINFO__PK}/plugin/

START_TIME=`date`

echo "father_genotype =" $PLUGINCONFIG__F_LIST
echo "mother_genotype =" $PLUGINCONFIG__M_LIST
echo "file_name_prefix =" $PLUGINCONFIG__FILE_NAME_PREFIX
FILE_PREFIX=$PLUGINCONFIG__FILE_NAME_PREFIX

if [ ! -f ${TSP_FILEPATH_BARCODE_TXT} ]; then
	echo "this plugin only support barcoded run"
	exit 1
fi

#echo -e $PLUGINCONFIG__FATHER_FILECONTENTS > father_input.txt
#echo -e $PLUGINCONFIG__MOTHER_FILECONTENTS > mother_input.txt


echo -e $PLUGINCONFIG__SAMPLESELECT | awk -F":" -vOFS="\t" '{if(NF>=2){gsub(" ","_",$2);printf("%s\t%s\n", $1, $2);}}' > selected_bc_samples.txt
PLUGIN_ID=`echo ${PLUGINCONFIG__PLUGINID}`
echo "PLUGIN_ID = "${PLUGIN_ID}
# plugin id check
if [ ! -d ${RESULTS_DIR}/../variantCaller_out.${PLUGIN_ID} ]; then
	echo "variantCaller_out."${PLUGIN_ID}" not found"
	exit 1
fi
echo "TVC = variantCaller_out."${PLUGIN_ID}
mkdir results

touch exist_bc_samples.txt
#
# using vcf files as the data source
#sort selected_bc_samples.txt | while read line
#do
#	BC_SAMPLE=${line}
#	echo "barcode_sample = "${BC_SAMPLE}
#	BC=`echo $BC_SAMPLE | awk '{print $1;}'`
#	if [ ! -d results/${BC} ]; then
#		mkdir results/${BC}
#	fi
#	if [ -f ${RESULTS_DIR}/../variantCaller_out.${PLUGIN_ID}/${BC}/TSVC_variants.vcf ]; then
#		cp -a ${RESULTS_DIR}/../variantCaller_out.${PLUGIN_ID}/${BC}/TSVC_variants.vcf results/${BC}.vcf
#		bgzip results/${BC}.vcf
#		tabix -p vcf results/${BC}.vcf.gz
#		echo ${BC_SAMPLE} >> exist_bc_samples.txt
#	else
#		echo ${RESULTS_DIR}/../variantCaller_out.${PLUGIN_ID}/${BC}/TSVC_variants.vcf" not found"
#	fi
#done
#cd results
#awk -vPREFIX=$FILE_PREFIX 'BEGIN{printf("vcf-merge");}{printf(" %s.vcf.gz", $1);} END{printf(" > %s_all.vcf\n", PREFIX);}' < ../exist_bc_samples.txt | bash
#CNT_SAMPLE=`awk -F"\t" '{if($1=="#CHROM")cnt_sample=NF-9;}END{printf("%d\n", cnt_sample);}' < ${FILE_PREFIX}_all.vcf`
#awk -vNSAMPLE=$CNT_SAMPLE '{\
#	if(substr($1,1,1)!="#"){\
#		split($8, info_array, ";");\
#		hs=0;\
#		for(i in info_array)if(info_array[i]=="HS")hs=1;\
#		if(hs){\
#			split($9, fmt_idx, ":");\
#			for(i=1;i<=length(fmt_idx);i++)if(fmt_idx[i]=="GT")gt_idx=i;else if(fmt_idx[i]=="FDP")fdp_idx=i;\
#			split($3, marker_id, ";");\
#			flg=0;\
#			for(i=2;i<=length(marker_id);i++)if(marker_id[i]!=marker_id[1])flg=1;\
#			printf("%s_%s\t%s\t%s\t", $1, $2, $1, $2);\
#			if(flg){\
#				for(i=1;i<=length(marker_id);i++){\
#					if(i>1)printf("/");\
#					printf("%s", marker_id[i]);\
#				}\
#			}\
#			else printf("%s", marker_id[1]);\
#			printf("\t%s\t%s", $4, $5);\
#			for(i=1;i<=NSAMPLE;i++){\
#				split($(9+i),fmt_val,":");\
#				if($(9+i)==".")printf("\t.");\
#				else if(fmt_val[gt_idx] == "./.")printf("\tNoCall_%d", fmt_val[fdp_idx]);\
#				else printf("\t%s", fmt_val[gt_idx]);\
#			}\
#			printf("\n");\
#		}\
#	}\
#}' < ${FILE_PREFIX}_all.vcf | sort -s -k1,1 > ${FILE_PREFIX}_all.txt
#
# using xls files as the data source
sort selected_bc_samples.txt | while read line
do
	BC_SAMPLE=${line}
	echo "barcode_sample = "${BC_SAMPLE}
	BC=`echo $BC_SAMPLE | awk '{print $1;}'`
	if [ -f ${RESULTS_DIR}/../variantCaller_out.${PLUGIN_ID}/${BC}/alleles.xls ]; then
		cp -a ${RESULTS_DIR}/../variantCaller_out.${PLUGIN_ID}/${BC}/alleles.xls results/${BC}_alleles.xls
		awk -F"\t" '{if(NR==1)for(i=1;i<=NF;i++){if($i=="Chrom")printf("export ID_CHR=%d\n", i);else if($i=="Allele Source")printf("export ID_ALLELESOURCE=%d\n", i);else if($i=="Allele Name")printf("export ID_ALLELENAME=%d\n", i);else if($i=="VCF Position")printf("export ID_VCFPOS=%d\n", i);else if($i=="VCF Ref")printf("export ID_VCFREF=%d\n", i);else if($i=="VCF Variant")printf("export ID_VCFVAR=%d\n", i);else if($i=="Coverage")printf("export ID_COV=%d\n", i);else if($i=="Allele Call")printf("export ID_CALL=%d\n", i);else if($i=="Region Name")printf("export ID_REGION=%d\n", i);}}' < results/${BC}_alleles.xls > results/${BC}_set_env
		source results/${BC}_set_env
		if [ ! -v ID_CHR ]; then echo "variantCaller_out."${PLUGIN_ID}"/"${BC}"/alleles.xls doesn't have a column Chrom."; fi
		if [ ! -v ID_ALLELESOURCE ]; then echo "variantCaller_out."${PLUGIN_ID}"/"${BC}"/alleles.xls doesn't have a column Allele Source."; fi
		if [ ! -v ID_ALLELENAME ]; then echo "variantCaller_out."${PLUGIN_ID}"/"${BC}"/alleles.xls doesn't have a column Allele Name."; fi
		if [ ! -v ID_VCFPOS ]; then echo "variantCaller_out."${PLUGIN_ID}"/"${BC}"/alleles.xls doesn't have a column VCF Position."; fi
		if [ ! -v ID_VCFREF ]; then echo "variantCaller_out."${PLUGIN_ID}"/"${BC}"/alleles.xls doesn't have a column VCF Ref."; fi
		if [ ! -v ID_VCFVAR ]; then echo "variantCaller_out."${PLUGIN_ID}"/"${BC}"/alleles.xls doesn't have a column VCF Variant."; fi
		if [ ! -v ID_COV ]; then echo "variantCaller_out."${PLUGIN_ID}"/"${BC}"/alleles.xls doesn't have a column Coverage."; fi
		if [ ! -v ID_CALL ]; then echo "variantCaller_out."${PLUGIN_ID}"/"${BC}"/alleles.xls doesn't have a column Allele Call."; fi
		if [ ! -v ID_REGION ]; then echo "variantCaller_out."${PLUGIN_ID}"/"${BC}"/alleles.xls doesn't have a column Region Name."; fi
		awk -F"\t" -vID_ALLELESOURCE=$ID_ALLELESOURCE -vID_ALLELENAME=$ID_ALLELENAME 'BEGIN{flg=0;}{if(NR>1 && $ID_ALLELESOURCE=="Hotspot"){if(index($ID_ALLELENAME, "#")!=0)flg=1;}}END{if(flg)printf("export ALLELENAME_PROHIBITED=1\n");}' < results/${BC}_alleles.xls > results/${BC}_set_env2
		source results/${BC}_set_env2
		if [ -v ALLELENAME_PROHIBITED ]; then echo "variantCaller_out."${PLUGIN_ID}"/"${BC}"/alleles.xls contains prohibited charactor(#) in Allele Name."; exit 1; fi
		awk -F"\t" -vID_CHR=$ID_CHR -vID_ALLELESOURCE=$ID_ALLELESOURCE -vID_ALLELENAME=$ID_ALLELENAME -vID_VCFPOS=$ID_VCFPOS -vID_VCFREF=$ID_VCFREF -vID_VCFVAR=$ID_VCFVAR -vID_COV=$ID_COV -vID_CALL=$ID_CALL \
			'{\
				if(NR>1 && $ID_ALLELESOURCE=="Hotspot"){\
					if($ID_CALL=="No Call")call=sprintf("NoCall_%d", $ID_COV);\
					else call=$ID_CALL;\
					len_ref=length($ID_VCFREF);\
					len_var=length($ID_VCFVAR);\
					len_min=(len_ref>len_var?len_var:len_ref);\
					pos=$ID_VCFPOS;\
					for(i=len_min;i>0;i--){if(substr($ID_VCFREF,len_ref + 1 - i)==substr($ID_VCFVAR,len_var + 1 - i))break;}\
					VCFREF=substr($ID_VCFREF,1,len_ref - i);\
					VCFVAR=substr($ID_VCFVAR,1,len_var - i);\
					len_ref-=i;\
					len_var-=i;\
					len_min-=i;\
					for(i=len_min;i>0;i--){if(substr(VCFREF,1,i)==substr(VCFVAR,1,i))break;}\
					if(len_ref!=len_var && i>0)i--;
					$ID_VCFPOS+=i;\
					VCFREF=substr(VCFREF, 1 + i);\
					VCFVAR=substr(VCFVAR, 1 + i);\
					printf("%s#%s#%s#%s#%s\t%s\n", $ID_CHR, $ID_VCFPOS, $ID_ALLELENAME, VCFREF, VCFVAR, call);\
				}\
			}' < results/${BC}_alleles.xls | sort -k1,1 -u > results/${BC}_alleles_hs.txt
		if [ ! -f allele_region_list.txt ]; then
			awk -F"\t" -vID_ALLELESOURCE=$ID_ALLELESOURCE -vID_ALLELENAME=$ID_ALLELENAME -vID_REGION=$ID_REGION \
				'{if(NR>1 && $ID_ALLELESOURCE=="Hotspot")printf("%s\t%s\n", $ID_ALLELENAME, $ID_REGION);}'\
				 < results/${BC}_alleles.xls > allele_region_list.txt
		fi
		unset ID_CHR ID_ALLELESOURCE ID_ALLELENAME ID_VCFPOS ID_VCFREF ID_VCFVAR ID_COV ID_CALL ID_REGION ALLELENAME_PROHIBITED
		#awk -F"\t" '{if(NR>1 && $11=="Hotspot"){if($5=="No Call")call=sprintf("NoCall_%d", $20); else call=$5; printf("%s:%s:%s:%s:%s\t%s\n", $1, $16, $12, $17, $18, call);}}' < results/${BC}_alleles.xls | sort -k1,1 -u > results/${BC}_alleles_hs.txt
		awk '{print $1;}' < results/${BC}_alleles_hs.txt >> results/name.txt
		echo ${BC_SAMPLE} >> exist_bc_samples.txt
	else
		echo ${RESULTS_DIR}/../variantCaller_out.${PLUGIN_ID}/${BC}/alleles.xls" not found"
	fi
done
cd results
awk -F" " '{sample_num=$2;gsub("[^0-9]","",sample_num);printf("%s %s %s\n", $1, $2, sample_num);}' < ../exist_bc_samples.txt > ../exist_bc_samples_list.txt
sort -u name.txt > name-u.txt
awk '{printf("join -a 1 name-u.txt %s_alleles_hs.txt | awk \x27{if(NF==2)print;else printf(\"%%s -\\n\", $1);}\x27 > %s_alleles_hs_fill.txt\n", $1, $1);}' < ../exist_bc_samples.txt | bash
awk -vPREFIX=$FILE_PREFIX 'BEGIN{printf("cat name-u.txt");}{printf(" | join - %s_alleles_hs_fill.txt > temp_file_%d\n", $1, NR);if(NR>1)printf("rm temp_file_%d\n", NR-1);printf("cat temp_file_%d", NR);}END{printf(" > %s_temp.txt\nrm temp_file_%d\n", PREFIX, NR);}' < ../exist_bc_samples.txt > join_alleles.sh
bash join_alleles.sh
awk -F" " '{split($1,array,"#");printf("%s\t%s\t%s\t%s\t%s\t%s", array[3], array[1], array[2], array[3], array[4], array[5]);for(i=2;i<=NF;i++)printf("\t%s", $i);printf("\n");}' < ${FILE_PREFIX}_temp.txt | sort -s -k1,1 > ${FILE_PREFIX}_all.txt

CNT_SAMPLE=`wc -l ../exist_bc_samples.txt | awk '{print $1}'`

# /using xls files as the data source

if [ "$PLUGINCONFIG__NOPARENTS" != "Yes" ]; then
	cd ..
	touch father_input.txt
	CNT=0;
	VARNAME="PLUGINCONFIG__FATHER_FILECONTENTSARRAY__"${CNT}
	while ! [ -z ${!VARNAME+x} ]
	do
        	#echo ${VARNAME}
        	echo -e -n ${!VARNAME} >> father_input.txt
        	CNT=`expr ${CNT} + 1`
        	VARNAME="PLUGINCONFIG__FATHER_FILECONTENTSARRAY__"${CNT}
	done
	
	touch mother_input.txt
	CNT=0;
	VARNAME="PLUGINCONFIG__MOTHER_FILECONTENTSARRAY__"${CNT}
	while ! [ -z ${!VARNAME+x} ]
	do
        	#echo ${VARNAME}
        	echo -e -n ${!VARNAME} >> mother_input.txt
        	CNT=`expr ${CNT} + 1`
        	VARNAME="PLUGINCONFIG__MOTHER_FILECONTENTSARRAY__"${CNT}
	done
	awk -F"," '{printf("%s\t%s\t%s\t%s\t%s\n", $3, $1, $2, $3, $4);}' < father_input.txt | sort -s -k1,1 > results/father.txt
	awk -F"," '{printf("%s\t%s\t%s\t%s\t%s\n", $3, $1, $2, $3, $4);}' < mother_input.txt | sort -s -k1,1 > results/mother.txt
	cd results

	#CHR POS ID FATHER MOTHER REF ALT SAMPLES...
	join father.txt mother.txt | join - ${FILE_PREFIX}_all.txt | awk -vNSAMPLE=$CNT_SAMPLE '{printf("%s\t%s\t%s\t%s\t%s\t%s\t%s", $2, $3, $12, $5, $9, $13, $14);for(i=1;i<=NSAMPLE;i++)printf("\t%s", $(14+i));printf("\n");}' > ${FILE_PREFIX}_parents_all.txt

# using vcf files as the data source
#	#CHR POS ID REF FATHER MOTHER SAMPLES...
#	awk -F"\t" -vOFS="," 'BEGIN{printf("#CHR,POS,ID,REF,FATHER,MOTHER");}{if($1=="#CHROM")for(i=10;i<=NF;i++)printf(",%s", $i);}END{printf("\n");}' < ${FILE_PREFIX}_all.vcf > ${FILE_PREFIX}_abh.csv
#	awk -vNSAMPLE=$CNT_SAMPLE '{\
#		printf("%s,%s,%s,%s,%s,%s", $1, $2, $3, $6, $4, $5);\
#		split($7,alt_array,",");\
#		a_nuc=$4;\
#		b_nuc=$5;\
#		a=-1;b=-1;\
#		if(a_nuc==$6)a=0;\
#		else for(i=1;i<=length(alt_array);i++)if(alt_array[i]==a_nuc)a=i;\
#		if(b_nuc==$6)b=0;\
#		else for(i=1;i<=length(alt_array);i++)if(alt_array[i]==b_nuc)b=i;\
#		for(i=1;i<=NSAMPLE;i++){\
#			split($(7+i),s_array,"/");\
#			if(length(s_array)!=2)s_type="-";\
#			else if(a!=-1&&s_array[1]==a&&s_array[2]==a)s_type="A";\
#			else if(b!=-1&&s_array[1]==b&&s_array[2]==b)s_type="B";\
#			else if((a!=-1&&b!=-1)&&(s_array[1]==a&&s_array[2]==b)||(s_array[1]==b&&s_array[2]==a))s_type="H";\
#			else s_type="-";\
#			printf(",%s", s_type);\
#		}\
#		printf("\n");\
#	}' < ${FILE_PREFIX}_parents_all.txt | sort -t"," -s -n -k2,2 | sort -t"," -s -k1,1 >> ${FILE_PREFIX}_abh.csv

# using xls files as the data source
	#CHR POS ID REF FATHER MOTHER SAMPLES...
	awk 'BEGIN{printf("#CHR,POS,ID,REF,FATHER,MOTHER");}{printf(",%s", $2);}END{printf("\n");}' < ../exist_bc_samples.txt > ${FILE_PREFIX}_abh.csv
	awk -vNSAMPLE=$CNT_SAMPLE '{\
		gsub(",","_",$3);\
        	printf("%s,%s,%s,%s,%s,%s", $1, $2, $3, $6, $4, $5);\
        	a_nuc=$4;\
        	b_nuc=$5;\
        	a=-1;b=-1;\
        	if(a_nuc==$6)a=0;\
        	else if(a_nuc==$7)a=1;\
        	if(b_nuc==$6)b=0;\
        	else if(b_nuc==$7)b=1;\
        	for(i=1;i<=NSAMPLE;i++){\
                	if($(7+i)=="Homozygous"){\
				if(a==1)s_type="A";\
				else if(b==1)s_type="B";\
				else s_type="-";\
			}\
                	else if($(7+i)=="Absent"){\
				if(a==0)s_type="A";\
				else if(b==0)s_type="B";\
				else s_type="-";\
			}\
                	else if($(7+i)=="Heterozygous"){\
				if(a==0&&b==1)s_type="H";
				else if(a==1&&b==0)s_type="H";
				else s_type="-";\
			}\
                	else s_type="-";\
                	printf(",%s", s_type);\
        	}\
        	printf("\n");\
	}' < ${FILE_PREFIX}_parents_all.txt | sort -t"," -s -n -k2,2 | sort -t"," -s -k1,1 >> ${FILE_PREFIX}_abh.csv
# /using xls files as the data source

	${DIRNAME}/transpose --fsep \, -t < ${FILE_PREFIX}_abh.csv > ${FILE_PREFIX}_abh_transpose.csv
	awk -F"," -vOFS="," '{if(NR==1){printf(",,");for(i=7;i<=NF;i++){gsub("[^0-9]","",$i);printf(",%d",$i);}printf("\n");}else{gsub("[^0-9]","",$1);printf("%s,%s,%s", $3, $1, $2);for(i=7;i<=NF;i++)printf(",%s",$i);printf("\n");}}' < ${FILE_PREFIX}_abh.csv > ${FILE_PREFIX}_genotype_input.csv

else
	echo "NoParents"
# using vcf files as the data source
#	#CHR POS ID REF ALT SAMPLES...
#	awk -F"\t" -vOFS="," 'BEGIN{printf("#Chrom,Position,ID,Ref,Variant");}{if($1=="#CHROM")for(i=10;i<=NF;i++)printf(",%s", $i);}END{printf("\n");}' < ${FILE_PREFIX}_all.vcf > ${FILE_PREFIX}_abh.csv
#	awk -vNSAMPLE=$CNT_SAMPLE '{\
#		printf("%s,%s,%s,%s,", $2, $3, $4, $5);\
#		split($6, alt_array, ",");\
#		for(i=1;i<=length(alt_array);i++){\
#			if(i!=1)printf("/");
#			printf("%s", alt_array[i]);\
#		}\
#		for(i=1;i<=NSAMPLE;i++){\
#			split($(6+i),s_array,"/");\
#			if($(6+i)==".")s_type=".";\
#			else if(substr($(6+i),1,6)=="NoCall")s_type=$(6+i);\
#			else if(s_array[1]=="0"&&s_array[2]=="0")s_type="Absent";\
#			else if(s_array[1]=="."||s_array[2]==".")s_type="NoCall";\
#			else if(s_array[1]==s_array[2])s_type=sprintf("Homozygous_%d",s_array[1]);\
#			else if(s_array[1]=="0")s_type=sprintf("Heterozygous_%d",s_array[2]);\
#			else if(s_array[2]=="0")s_type=sprintf("Heterozygous_%d",s_array[1]);\
#			else s_type=sprintf("Mixed_%d_%d",s_array[1],s_array[2]);\
#			printf(",%s", s_type);\
#		}\
#		printf("\n");\
#	}' < ${FILE_PREFIX}_all.txt | sort -t"," -s -n -k2,2 | sort -t"," -s -k1,1 >> ${FILE_PREFIX}_abh.csv


# using xls files as the data source
	#CHR POS ID REF ALT SAMPLES...
	awk 'BEGIN{printf("#Chrom,Position,ID,Ref,Variant");}{printf(",%s", $2);}END{printf("\n");}' < ../exist_bc_samples.txt > ${FILE_PREFIX}_allele.csv
	awk -vNSAMPLE=$CNT_SAMPLE '{\
		gsub(",","_",$4);\
        	printf("%s,%s,%s,%s,%s", $2, $3, $4, $5, $6);\
        	for(i=1;i<=NSAMPLE;i++)printf(",%s", $(6+i));\
        	printf("\n");\
	}' < ${FILE_PREFIX}_all.txt | sort -t"," -s -n -k2,2 | sort -t"," -s -k1,1 >> ${FILE_PREFIX}_allele.csv

	${DIRNAME}/transpose --fsep \, -t < ${FILE_PREFIX}_allele.csv > ${FILE_PREFIX}_allele_transpose.csv

# /using xls files as the data source
	awk -vNSAMPLE=$CNT_SAMPLE '{printf("%s\t%s\t%s\t%s\t%s\t%s\t%s", $2, $3, $4, $5, $6, $5, $6);for(i=1;i<=NSAMPLE;i++)printf("\t%s", $(6+i));printf("\n");}' < ${FILE_PREFIX}_all.txt > ${FILE_PREFIX}_tentativeParents_all.txt
	#CHR POS ID REF FATHER MOTHER SAMPLES...
	awk 'BEGIN{printf("#CHR,POS,ID,REF=A,ALT=B");}{printf(",%s", $2);}END{printf("\n");}' < ../exist_bc_samples.txt > ${FILE_PREFIX}_abh.csv
	awk -vNSAMPLE=$CNT_SAMPLE '{\
		gsub(",","_",$3);\
        	printf("%s,%s,%s,%s,%s", $1, $2, $3, $4, $5);\
        	a_nuc=$4;\
        	b_nuc=$5;\
        	a=-1;b=-1;\
        	if(a_nuc==$6)a=0;\
        	else if(a_nuc==$7)a=1;\
        	if(b_nuc==$6)b=0;\
        	else if(b_nuc==$7)b=1;\
        	for(i=1;i<=NSAMPLE;i++){\
                	if($(7+i)=="Homozygous"){\
				if(a==1)s_type="A";\
				else if(b==1)s_type="B";\
				else s_type="-";\
			}\
                	else if($(7+i)=="Absent"){\
				if(a==0)s_type="A";\
				else if(b==0)s_type="B";\
				else s_type="-";\
			}\
                	else if($(7+i)=="Heterozygous"){\
				if(a==0&&b==1)s_type="H";
				else if(a==1&&b==0)s_type="H";
				else s_type="-";\
			}\
                	else s_type="-";\
                	printf(",%s", s_type);\
        	}\
        	printf("\n");\
	}' < ${FILE_PREFIX}_tentativeParents_all.txt | sort -t"," -s -n -k2,2 | sort -t"," -s -k1,1 >> ${FILE_PREFIX}_abh.csv
	${DIRNAME}/transpose --fsep \, -t < ${FILE_PREFIX}_abh.csv > ${FILE_PREFIX}_abh_transpose.csv
	awk -F"," -vOFS="," '{if(NR==1){printf(",,");for(i=7;i<=NF;i++){gsub("[^0-9]","",$i);printf(",%d",$i);}printf("\n");}else{gsub("[^0-9]","",$1);printf("%s,%s,%s", $3, $1, $2);for(i=7;i<=NF;i++)printf(",%s",$i);printf("\n");}}' < ${FILE_PREFIX}_abh.csv > ${FILE_PREFIX}_abh_ref_base.csv
fi

cd ..

echo "<html><body>" > ABH_block.html
echo "<a>started at:" $START_TIME "</a><br>" >> ABH_block.html
echo "TVC_ID = "${PLUGIN_ID}"</br>" >> ABH_block.html
echo "<br>" >> ABH_block.html
if [ "$PLUGINCONFIG__NOPARENTS" == "Yes" ]; then
	echo "<a>No parents' genotype provided</a><br>" >> ABH_block.html
else
	echo "<a>father genotype=</a><a href="${TSP_URLPATH_PLUGIN_DIR}"/father_input.txt>"$PLUGINCONFIG__F_LIST"</a><br>" >> ABH_block.html
	echo "<a>mother genotype=</a><a href="${TSP_URLPATH_PLUGIN_DIR}"/mother_input.txt>"$PLUGINCONFIG__M_LIST"</a><br>" >> ABH_block.html
fi
echo "[Results]&nbsp;" >> ABH_block.html
echo "<br>" >> ABH_block.html
echo "<a>list of barcode/sample used:</a><a href="${TSP_URLPATH_PLUGIN_DIR}"/exist_bc_samples_list.txt>bc_samples.txt</a><br>" >> ABH_block.html
echo "<a>list of markers with region names:</a><a href="${TSP_URLPATH_PLUGIN_DIR}"/allele_region_list.txt>allele_region_list.txt</a><br>" >> ABH_block.html
if [ "$PLUGINCONFIG__NOPARENTS" != "Yes" ]; then
	echo "<a>ABH(marker in row/sample in column):</a><a href="${TSP_URLPATH_PLUGIN_DIR}"/results/${FILE_PREFIX}_abh.csv>${FILE_PREFIX}_abh.csv</a><br>" >> ABH_block.html
	echo "<a>ABH(marker in column/sample in row):</a><a href="${TSP_URLPATH_PLUGIN_DIR}"/results/${FILE_PREFIX}_abh_transpose.csv>${FILE_PREFIX}_abh_transpose.csv</a><br>" >> ABH_block.html
	echo "<a>ABH(R/qtl,IonBreeders):</a><a href="${TSP_URLPATH_PLUGIN_DIR}"/results/${FILE_PREFIX}_genotype_input.csv>${FILE_PREFIX}_genotype_input.csv</a><br>" >> ABH_block.html
else
	echo "<a>Allele Call(marker in row/sample in column):</a><a href="${TSP_URLPATH_PLUGIN_DIR}"/results/${FILE_PREFIX}_allele.csv>${FILE_PREFIX}_allele.csv</a><br>" >> ABH_block.html
	echo "<a>Allele Call(marker in column/sample in row):</a><a href="${TSP_URLPATH_PLUGIN_DIR}"/results/${FILE_PREFIX}_allele_transpose.csv>${FILE_PREFIX}_allele_transpose.csv</a><br>" >> ABH_block.html
	echo "<a>ABH(marker in row/sample in column):</a><a href="${TSP_URLPATH_PLUGIN_DIR}"/results/${FILE_PREFIX}_abh.csv>${FILE_PREFIX}_abh.csv</a><br>" >> ABH_block.html
	echo "<a>ABH(marker in column/sample in row):</a><a href="${TSP_URLPATH_PLUGIN_DIR}"/results/${FILE_PREFIX}_abh_transpose.csv>${FILE_PREFIX}_abh_transpose.csv</a><br>" >> ABH_block.html
	echo "<a>ABH(R/qtl,IonBreeders):</a><a href="${TSP_URLPATH_PLUGIN_DIR}"/results/${FILE_PREFIX}_abh_ref_base.csv>${FILE_PREFIX}_abh_ref_base.csv</a><br>" >> ABH_block.html
fi
echo "</body></html>" >> ABH_block.html
